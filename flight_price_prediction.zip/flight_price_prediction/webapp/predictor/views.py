import os
import numpy as np
import joblib
from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.http import require_POST

# ── Model path (relative to this file's location) ────────────────────────────
BASE_DIR   = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MODEL_PATH = os.path.join(
    BASE_DIR, '..', '..', 'models', 'flight_price_rf_model.joblib'
)

# ── Load model once at import time ────────────────────────────────────────────
_payload = None

def load_payload():
    global _payload
    if _payload is None:
        model_abs = os.path.abspath(MODEL_PATH)
        if not os.path.exists(model_abs):
            raise FileNotFoundError(
                f"Model not found at {model_abs}. "
                "Please run `python train_model.py` from the project root first."
            )
        _payload = joblib.load(model_abs)
    return _payload

# ── Choice options for the form ───────────────────────────────────────────────
AIRLINES       = ['Air India', 'GoAir', 'IndiGo', 'Jet Airways', 'SpiceJet', 'Vistara']
CITIES         = ['Bangalore', 'Chennai', 'Cochin', 'Delhi', 'Hyderabad', 'Kolkata', 'Mumbai']
TIME_OPTIONS   = ['Early Morning', 'Morning', 'Noon', 'Afternoon', 'Evening', 'Night']
STOPS_OPTIONS  = ['0', '1', '2 or more']
CLASS_OPTIONS  = ['Economy', 'Business']


def index(request):
    context = {
        'airlines':     AIRLINES,
        'cities':       CITIES,
        'time_options': TIME_OPTIONS,
        'stops_options': STOPS_OPTIONS,
        'class_options': CLASS_OPTIONS,
    }
    return render(request, 'predictor/index.html', context)


@require_POST
def predict(request):
    try:
        payload   = load_payload()
        model     = payload['model']
        encoders  = payload['encoders']
        stops_map = payload['stops_map']
        time_map  = payload['time_map']

        # ── Parse form inputs ─────────────────────────────────────────────────
        airline         = request.POST.get('airline', 'IndiGo')
        source_city     = request.POST.get('source_city', 'Delhi')
        destination_city = request.POST.get('destination_city', 'Mumbai')
        departure_time  = request.POST.get('departure_time', 'Morning')
        arrival_time    = request.POST.get('arrival_time', 'Afternoon')
        stops           = request.POST.get('stops', '1')
        travel_class    = request.POST.get('travel_class', 'Economy')
        duration        = float(request.POST.get('duration', 2.5))
        days_left       = int(request.POST.get('days_left', 15))

        # ── Encode categoricals ───────────────────────────────────────────────
        def safe_encode(encoder, value, default=0):
            if value in encoder.classes_:
                return int(encoder.transform([value])[0])
            return default

        airline_enc    = safe_encode(encoders['airline'], airline)
        src_enc        = safe_encode(encoders['source_city'], source_city)
        dst_enc        = safe_encode(encoders['destination_city'], destination_city)
        class_enc      = safe_encode(encoders['travel_class'], travel_class)
        stops_num      = stops_map.get(stops, 1)
        dep_time_num   = time_map.get(departure_time, 1)
        arr_time_num   = time_map.get(arrival_time, 3)

        # ── Build feature vector ──────────────────────────────────────────────
        features = np.array([[
            airline_enc,
            src_enc,
            dep_time_num,
            stops_num,
            arr_time_num,
            dst_enc,
            class_enc,
            duration,
            days_left,
        ]])

        prediction = model.predict(features)[0]

        return JsonResponse({
            'success': True,
            'price':   round(float(prediction), 2),
            'price_formatted': f'₹{prediction:,.0f}',
        })

    except FileNotFoundError as e:
        return JsonResponse({'success': False, 'error': str(e)}, status=503)
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)}, status=400)
